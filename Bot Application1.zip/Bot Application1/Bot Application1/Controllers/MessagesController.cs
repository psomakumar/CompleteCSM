﻿using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;
using Microsoft.Bot.Connector;
using Newtonsoft.Json;
using System.Collections.Generic;
using Microsoft.Bot.Builder.Dialogs;

namespace Bot_Application1
{
    [BotAuthentication]
    public class MessagesController : ApiController
    {
        /// <summary>
        /// POST: api/Messages
        /// Receive a message from a user and reply to it
        /// app id password:  CompleteCSMBot1    LSEUTbPEywqVJmhkbd8MLdG
        /// app id fca3183a-d011-4796-9a78-13a5ff0f3e93 
        /// 
        /// slack  client id 101442615492.101456898597
        /// slack client secret  951b1c104c312d9ab9754d6948047598
        /// 
        /// twillio appid  AC9f4a95ba99ffcbada7f87263cdde21b3
        /// twilios token 11fc12f271fb5689db5baf8baa01bf2b
        /// twilio phone  (469) 617-2019
        /// </summary>
        public async Task<HttpResponseMessage> Post([FromBody]Activity activity)
        {


            // check if activity is of type message
            if (activity != null && activity.GetActivityType() == ActivityTypes.Message)
            {
                await Conversation.SendAsync(activity, () => new EchoDialog());

               
            }
            else
            {
                HandleSystemMessage(activity);
            }
            return new HttpResponseMessage(System.Net.HttpStatusCode.Accepted);

            /*
            if (activity.Type == ActivityTypes.Message)
            {
                ConnectorClient connector = new ConnectorClient(new Uri(activity.ServiceUrl));
                // calculate something for us to return
                int length = (activity.Text ?? string.Empty).Length;

                // return our reply to the user
                Activity reply = activity.CreateReply($"You sent {activity.Text} which was {length} characters and many more");
                //reply.Attachments.Add(addMultimedia());
                

                //connector.Conversations.ReplyToActivity(reply.CreateReply("another reply1"));
                //connector.Conversations.ReplyToActivity(reply.CreateReply("another reply2"));
                await connector.Conversations.ReplyToActivityAsync(reply);
            }
            else
            {
                HandleSystemMessage(activity);
            }
            var response = Request.CreateResponse(HttpStatusCode.OK);
            return response;
            */
        }
        private Address botaddress = null;
       


private Attachment addMultimedia()
        {
            //message.Attachments.Add()
            List<CardImage> cardImages = new List<CardImage>();
            cardImages.Add(new CardImage(url: "http://yourcsm.com/wp-content/uploads/2016/09/completecsmlogo5orangeblue.png"));


            List<CardAction> cardButtons = new List<CardAction>();
            CardAction plButton = new CardAction()
            {
                Value = "https://en.wikipedia.org/wiki/Pig_Latin",
                Type = "openUrl",
                Title = "WikiPedia Page"
            };
            cardButtons.Add(plButton);


            HeroCard plCard = new HeroCard()
            {
                Title = "I'm a hero card",
                Subtitle = "Pig Latin Wikipedia Page",

                //add the image and buttons
                Images = cardImages,
                Buttons = cardButtons
            };

            //create attachment
            Attachment plAttachment = plCard.ToAttachment();


            return plAttachment;
        }

        ReceiptItem lineItem1 = new ReceiptItem()
        {
            Title = "Pork Shoulder",
            Subtitle = "8 lbs",
            Text = null,
            Image = new CardImage(url: "https://<ImageUrl1>"),
            Price = "16.25",
            Quantity = "1",
            Tap = null
        };

   
        private Activity HandleSystemMessage(Activity message)
        {
            if (message.Type == ActivityTypes.DeleteUserData)
            {
                // Implement user deletion here
                // If we handle user deletion, return a real message
            }
            else if (message.Type == ActivityTypes.ConversationUpdate)
            {
                // Handle conversation state changes, like members being added and removed
                // Use Activity.MembersAdded and Activity.MembersRemoved and Activity.Action for info
                // Not available in all channels
            }
            else if (message.Type == ActivityTypes.ContactRelationUpdate)
            {
                // Handle add/remove from contact lists
                // Activity.From + Activity.Action represent what happened
            }
            else if (message.Type == ActivityTypes.Typing)
            {
                // Handle knowing tha the user is typing
            }
            else if (message.Type == ActivityTypes.Ping)
            {
            }

            return null;
        }

        [Serializable]
        public class EchoDialog : IDialog<object>
        {
            protected int count = 1;
            public async Task StartAsync(IDialogContext context)
            {
                context.Wait(MessageReceivedAsync);
            }
            public virtual async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> argument)
            {
                var message = await argument;
                if (message.Text == "reset")
                {
                    PromptDialog.Confirm(
                        context,
                        AfterResetAsync,
                        "Are you sure you want to reset the count?",
                        "Didn't get that!",
                        promptStyle: PromptStyle.None);
                }
                else
                {
                    await context.PostAsync($"{this.count++}: You said {message.Text}");
                    context.Wait(MessageReceivedAsync);
                }
            }
            public async Task AfterResetAsync(IDialogContext context, IAwaitable<bool> argument)
            {
                var confirm = await argument;
                if (confirm)
                {
                    this.count = 1;
                    await context.PostAsync("Reset count.");
                }
                else
                {
                    await context.PostAsync("Did not reset count.");
                }
                context.Wait(MessageReceivedAsync);
            }
        }
    }
}